import sys
import random
from random import randint
from PyQt5.QtMultimedia import QSound
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import  QMainWindow, QGridLayout, QWidget, QPushButton, QCheckBox, QComboBox
from PyQt5.QtCore import QTimer, QTime, pyqtSignal
from PyQt5.QtGui import QFont
import json


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.backdimg = "whinter.png"
        self.theme_color = '#4472C4'
        self.selected_index = 0
        self.pm = True
        self.flscr = True
        self.counter = True
        self.timer = True
        self.help = True
        self.errct= 0
        self.diff = 0
        self.clk_snd = QSound('btnsound.wav')
        if self.flscr:
            self.showFullScreen()
        self.ini_win()

    def ini_win(self):
        self.setWindowTitle('Судоку')
        self.setGeometry(0, 0, 1920, 1080)
        self.mainscreen()

    def mainscreen(self):
        self.clear_window()
        self.set_background(self.backdimg)
        self.create_label("Судоку", 680, 100, 600, 170, 150, self.theme_color, "bold")
        self.create_button("Начать игру", 860, 350, 200, 70, self.theme_color, self.prestart, inv_cal=True)
        self.create_button("Настройки", 860, 450, 200, 70, self.theme_color, self.settings_screen)
        self.create_button("Рекорды", 860, 550, 200, 70, self.theme_color, self.recordscr)
        self.create_button("Выход", 860, 650, 200, 70, self.theme_color, quit)

    def settings_screen(self):
        self.clear_window()
        self.set_background(self.backdimg)
        self.create_label("Выбор темы:", 860, 100, 380, 100, 25, self.theme_color, "none")
        self.create_label("Прочее:", 860, 240, 380, 100, 25, self.theme_color, "none")
        self.create_button("Назад", 1200, 500, 100, 70, self.theme_color, self.mainscreen)

        self.combo_box = QComboBox(self)
        self.combo_box.setGeometry(860, 180, 200, 30)
        self.combo_box.addItems(["Зима", "Сакура", "Лес"])
        self.combo_box.setCurrentIndex(self.selected_index)
        self.combo_box.currentIndexChanged.connect(self.changeStyle)
        self.combo_box.setStyleSheet(self.get_combobox_style())
        self.combo_box.show()

        self.checkbox1 = QCheckBox('         Звуки           ', self)
        self.checkbox1.setGeometry(860, 320, 200, 30)
        self.checkbox1.setStyleSheet(
            "QCheckBox { border-radius: 15px; background-color: "+ self.theme_color+"; color: white; font-size: 20px; border: 2px solid "+ self.theme_color+"} "
            "QCheckBox::indicator { border-radius: 6px; background-color: %s; border: 1px solid rgba(255,255,255,0) }" % (
                self.theme_color if self.pm else '#ffffff'))
        self.checkbox1.setChecked(self.pm)
        self.checkbox1.stateChanged.connect(self.checkbox_changed)
        self.checkbox1.show()

        self.checkbox = QCheckBox('  Полный экран      ', self)
        self.checkbox.setGeometry(860, 380, 200, 30)
        self.checkbox.setStyleSheet(
            "QCheckBox { border-radius: 15px; background-color: "+ self.theme_color+"; color: white; font-size: 20px; border: 2px solid "+ self.theme_color+"} "
            "QCheckBox::indicator { border-radius: 6px; background-color: %s; border: 1px solid rgba(255,255,255,0) }" % (
                self.theme_color if self.flscr else '#ffffff'))
        self.checkbox.setChecked(self.flscr)
        self.checkbox.stateChanged.connect(self.checkbox_changed1)
        self.checkbox.show()

    def recordscr(self):
        self.clear_window()
        self.set_background(self.backdimg)
        self.create_label("ВАШИ РЕКОРДЫ:", 860, 100, 380, 100, 25, self.theme_color, "bold")
        self.create_label("_________________________________", 700, 120, 600, 100, 25, self.theme_color, "bold")
        self.create_button("Назад", 1200, 900, 100, 70, self.theme_color, self.mainscreen)

        records = self.load_records()
        if records:
            sorted_records = sorted(records, key=lambda x: x.get("time", float('inf')))
            top_records = sorted_records[:10] 
            for i, record in enumerate(top_records, start=1):
                if "difficulty" in record and "time" in record:
                    difficulty = record["difficulty"]
                    time_str = record["time"]
                    self.create_label(f"{i}. Уровень сложности: {difficulty}, Время: {time_str}", 700, 180 + i * 40,
                                      600, 30,
                                      20, self.theme_color, "none")
                else:
                    self.create_label(f"Запись {i} имеет неполные данные", 700, 180 + i * 40, 600, 30, 20,
                                      self.theme_color, "none")
        else:
            self.create_label("Нет сохраненных рекордов", 700, 180, 600, 30, 20, self.theme_color, "none")

    def load_records(self):
        try:
            with open("records.json", "r") as file:
                records = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            records = []
        return records

    def prestart(self):
        self.clear_window()
        self.set_background(self.backdimg)

        self.checkbox2_0 = QCheckBox('         Таймер           ', self)
        self.checkbox2_0.setGeometry(860, 320, 200, 30)
        self.checkbox2_0.setStyleSheet(
            "QCheckBox { border-radius: 15px; background-color: "+ self.theme_color+"; color: white; font-size: 20px; border: 2px solid "+ self.theme_color+"} "
            "QCheckBox::indicator { border-radius: 6px; background-color: %s; border: 1px solid rgba(255,255,255,0) }" % (
                self.theme_color if self.timer else '#ffffff'))
        self.checkbox2_0.setChecked(self.timer)
        self.checkbox2_0.stateChanged.connect(self.checkbox_changed2)
        self.checkbox2_0.show()

        self.checkbox2_1 = QCheckBox('        Подсказки      ', self)
        self.checkbox2_1.setGeometry(860, 360, 200, 30)
        self.checkbox2_1.setStyleSheet(
            "QCheckBox { border-radius: 15px; background-color: "+ self.theme_color+"; color: white; font-size: 20px; border: 2px solid "+ self.theme_color+"} "
            "QCheckBox::indicator { border-radius: 6px; background-color: %s; border: 1px solid rgba(255,255,255,0) }" % (
                self.theme_color if self.help else '#ffffff'))
        self.checkbox2_1.setChecked(self.help)
        self.checkbox2_1.stateChanged.connect(self.checkbox_changed3)
        self.checkbox2_1.show()

        self.checkbox2_2 = QCheckBox('  Счетчик ошибок      ', self)
        self.checkbox2_2.setGeometry(860, 400, 200, 30)
        self.checkbox2_2.setStyleSheet(
            "QCheckBox { border-radius: 15px; background-color: "+ self.theme_color+"; color: white; font-size: 20px; border: 2px solid "+ self.theme_color+"} "
            "QCheckBox::indicator { border-radius: 6px; background-color: %s; border: 1px solid rgba(255,255,255,0) }" % (
                self.theme_color if self.counter else '#ffffff'))
        self.checkbox2_2.setChecked(self.counter)
        self.checkbox2_2.stateChanged.connect(self.checkbox_changed4)
        self.checkbox2_2.show()

        self.create_label("Уровень сложности:", 860, 220, 200, 30, 20, self.theme_color, "none")
        self.difficulty_combo_box = QComboBox(self)
        self.difficulty_combo_box.setGeometry(860, 260, 200, 30)
        self.difficulty_combo_box.addItems(["Лёгкий", "Средний", "Сложный"])
        self.difficulty_combo_box.setCurrentIndex(self.diff)
        self.difficulty_combo_box.currentIndexChanged.connect(self.change_difficulty)
        self.difficulty_combo_box.setStyleSheet(self.get_combobox_style())
        self.difficulty_combo_box.show()

        self.create_button("Назад", 1200, 900, 100, 70, self.theme_color, self.mainscreen)
        self.create_button("Начать игру", 860, 500, 200, 70, self.theme_color, self.game, inv_cal=True)

        self.diff_str = self.difficulty_combo_box.currentText()

    def change_difficulty(self, index):
        self.diff = index

    def game(self):
        self.clear_window()
        self.set_background(self.backdimg)

        self.create_label(f'{self.difficulty_combo_box.currentText()}', 865, 65, 380, 100, 25, self.theme_color, "bold")

        if self.help:
            self.create_button("Открыть клетку", 1100, 110, 200, 70, self.theme_color, self.open_cell, inv_cal=True)

        self.sudoku_grid = SudokuGrid(self, self.diff, self.help, self.timer, self.counter)
        self.sudoku_grid.setGeometry(665, 200, 600, 600)
        self.sudoku_grid.show()

        if self.counter:
            self.error_label = QtWidgets.QLabel(f'Ошибки: {self.errct}/3', self)
            self.error_label.setGeometry(865, 110, 200, 70)
            self.error_label.setFont(QFont('Times', 20))
            self.error_label.setStyleSheet(
                f'color: {self.theme_color}; font-size: {25}px; background-color: rgba(255,255,255,0); border-radius: 15px; font-weight: bold')
            self.error_label.show()
            self.sudoku_grid.erct.connect(self.update_error_counter_label)

        if self.timer:
            self.timer_label = QtWidgets.QLabel("Время: 00:00", self)
            self.timer_label.setGeometry(865, 150, 200, 50)
            self.timer_label.setFont(QFont('Times', 20))
            self.timer_label.setStyleSheet(
                f'color: {self.theme_color}; font-size: {25}px; background-color: rgba(255,255,255,0); border-radius: 15px; font-weight: bold')
            self.timer_label.show()
            self.sudoku_grid.time_updated.connect(self.update_timer_label)
        else:
            self.timer_label = None
        self.sudoku_grid.game_ended.connect(self.game_end)

        self.create_button("Назад", 1200, 900, 100, 70, self.theme_color, self.back)

    def back(self):
        self.errct = 0
        self.mainscreen()

    def update_timer_label(self, time_str):
        if self.timer_label:
            self.timer_label.setText(f"Время: {time_str}")

    def update_error_counter_label(self, error_count):
        if self.counter:
            self.errct = error_count
            self.error_label.setText(f'Ошибки: {self.errct}/3')

    def open_cell(self):
        self.sudoku_grid.open_random_cell()

    def game_end(self):
        self.save_records()

    def save_records(self):
        try:
            with open("records.json", "r") as file:
                records = json.load(file)
        except FileNotFoundError:
            records = []
        # Формируем запись для сохранения в файл
        record = {
            "difficulty": self.diff_str,
            "time": self.timer_label.text().split(": ")[1]
        }
        records.append(record)
        with open("records.json", "w") as file:
            json.dump(records, file, indent=4)
        self.recordscr()

    def checkbox_changed(self, state):
        self.pm = state == 2
        self.update_checkbox_style(self.checkbox1, self.pm)

    def checkbox_changed1(self, state):
        self.flscr = state == 2
        if self.flscr:
            self.showFullScreen()
        else:
            self.showNormal()
            self.setGeometry(0, 25, 1920, 1080)
        self.update_checkbox_style(self.checkbox, self.flscr)

    def checkbox_changed2(self, state):
        self.timer = state == 2
        self.update_checkbox_style(self.checkbox2_0, self.timer)

    def checkbox_changed3(self, state):
        self.help = state == 2
        self.update_checkbox_style(self.checkbox2_1, self.help)

    def checkbox_changed4(self, state):
        self.counter = state == 2
        if not self.counter:
            self.errct = 0
        self.update_checkbox_style(self.checkbox2_2, self.counter)

    def update_checkbox_style(self, checkbox, checked):
        checkbox.setStyleSheet(
            "QCheckBox { border-radius: 15px; background-color: " + self.theme_color + "; color: white; font-size: 20px; border: 2px solid " + self.theme_color + "} "
            "QCheckBox::indicator { border-radius: 6px; background-color: %s; border: 1px solid rgba(255,255,255,0) }" % (
                self.theme_color if checked else '#ffffff'))

    def changeStyle(self, index):
        styles = [
            ('#4472C4', 'whinter.png'),
            ('#ff98d0', 'sakura.png'),
            ('#6d912d', 'forest.png')
        ]
        self.theme_color, self.backdimg = styles[index]
        self.selected_index = index
        self.settings_screen()

    def clear_window(self):
        for widget in self.findChildren(QtWidgets.QWidget):
            widget.deleteLater()

    def create_label(self, text, sx, sy, x, y, size, color, weight):
        label = QtWidgets.QLabel(text, self)
        label.setGeometry(sx, sy, x, y)
        label.setStyleSheet(
            f'color: {color}; font-size: {size}px; background-color: rgba(255,255,255,0); border-radius: 15px; font-weight: {weight}')
        label.show()

    def create_button(self, text, sx, sy, x, y, color, action, inv_cal=False):
        button = QPushButton(text, self)
        button.setGeometry(sx, sy, x, y)
        text_color = 'white' if not inv_cal else color
        bg_color = color if not inv_cal else 'white'
        border_color = color if not inv_cal else 'white'
        button.setStyleSheet(
            f'color: {text_color}; border: 3px solid {border_color}; background-color: {bg_color}; font-size: 20px; border-radius: 30px;')
        button.clicked.connect(lambda: self.on_clk(action))
        button.show()

    def on_clk(self,action):
        if self.pm:
            self.clk_snd.play()
        action()

    def create_checkbox(self, text, x, y, checked, callback):
        checkbox = QCheckBox(text, self)
        checkbox.setGeometry(x, y, 200, 30)
        checkbox.setChecked(checked)
        checkbox.stateChanged.connect(callback)
        self.update_checkbox_style(checkbox, checked)
        checkbox.show()

    def set_background(self, img):
        background_label = QtWidgets.QLabel(self)
        background_label.setPixmap(QtGui.QPixmap(img))
        background_label.setGeometry(0, 0, self.width(), self.height())
        background_label.show()

    def get_combobox_style(self):
        return (
            "QComboBox { border-radius: 10px; background-color: rgba(255,255,255,128); color: " + self.theme_color + "; font-size: 20px; border: 2px solid " + self.theme_color + "; } " +
            "QComboBox QAbstractItemView { border-radius: 0px; background-color: #ffffff; color: " + self.theme_color + "; font-size: 20px; border: 2px solid " + self.theme_color + "; }"
        )

def generate_sudoku(diff):
    sudokulist = [[0]*9 for _ in range(9)]
    secondlst = [[0]*9 for _ in range(9)]
    num = 1

    for i in range(9):
        for c in range(9):
            sudokulist[0][i] = num
        num += 1

    for i in range(1, 9):
        sudokulist[i][0] = sudokulist[i-1][0] + 3
        if sudokulist[i][0] > 9:
            sudokulist[i][0] -= 8

    for i in range(1, 9):
        for c in range(1, 9):
            sudokulist[i][c] = sudokulist[i][c-1] + 1
            if sudokulist[i][c] > 9:
                sudokulist[i][c] = 1

    def swap_columns(m, n):
        for i in range(9):
            sudokulist[i][m-1], sudokulist[i][n-1] = sudokulist[i][n-1], sudokulist[i][m-1]

    swap_columns(9, 7)
    swap_columns(3, 1)

    empty_chance = {0: 80, 1: 40, 2: 20}

    for i in range(9):
        for c in range(9):
            chance = randint(1, 100)
            if chance < empty_chance[diff]:
                secondlst[i][c] = sudokulist[i][c]
    return sudokulist,secondlst
class SudokuGrid(QWidget):
    game_ended = pyqtSignal()
    erct = pyqtSignal(int)
    time_updated = pyqtSignal(str)

    def __init__(self, parent=None, diff=0, help=False, timer=False, counter=False):
        super().__init__(parent)
        self.error_count = 0
        self.diff = diff
        self.help = help
        self.timer_enabled = timer
        self.counter_enabled = counter

        self.layout = QGridLayout()
        self.buttons = [[QPushButton() for _ in range(9)] for _ in range(9)]
        self.sudokulist, self.generated_grid = generate_sudoku(self.diff)
        self.selected_button = None
        self.current_text_color = QtGui.QColor('#00bfff')
        self.setLayout(self.layout)
        self.init_grid()

        if self.timer_enabled:
            self.timer = QTimer(self)
            self.timer.timeout.connect(self.update_timer)
            self.timer.start(1000)
            self.current_time = QTime(0, 0, 0)
        else:
            self.timer = None

    def update_timer(self):
        if self.timer_enabled:
            self.current_time = self.current_time.addSecs(1)
            time_str = self.current_time.toString("mm:ss")
            self.time_updated.emit(time_str)

    def init_grid(self):
        for i in range(9):
            for j in range(9):
                button = self.buttons[i][j]
                button.setFixedSize(60, 60)
                button.setFont(QtGui.QFont("Arial", 18))
                button.setStyleSheet('background-color: white; border: 1px solid black; border-radius: 10px;')
                if self.generated_grid[i][j] != 0:
                    button.setText(str(self.generated_grid[i][j]))
                    button.setStyleSheet(
                        f'background-color: white; border: 1px solid black; border-radius: 10px; color: {self.current_text_color.name()};')
                    button.setEnabled(False)
                else:
                    button.clicked.connect(self.button_clicked)
                self.layout.addWidget(button, i, j)

    def button_clicked(self):
        button = self.sender()
        if button.isEnabled():
            if self.selected_button:
                self.selected_button.setStyleSheet(
                    f'background-color: white; border: 1px solid black; border-radius: 10px; color: {self.current_text_color.name()};')
            self.selected_button = button
            self.selected_button.setStyleSheet(
                'background-color: lightgray; border: 1px solid black; border-radius: 10px;')

    def keyPressEvent(self, event):
        if self.selected_button:
            key = event.key()
            if QtCore.Qt.Key_1 <= key <= QtCore.Qt.Key_9:
                digit = chr(key) if QtCore.Qt.Key_1 <= key <= QtCore.Qt.Key_9 else str(key - QtCore.Qt.Key_0)
                self.selected_button.setText(digit)
                row, col = self.get_button_position(self.selected_button)
                if 0 <= row < 9 and 0 <= col < 9:
                    if digit == str(self.sudokulist[row][col]):
                        self.selected_button.setStyleSheet(
                            'background-color: white; border: 1px solid black; border-radius: 10px; color: #3474eb;')
                    else:
                        self.selected_button.setStyleSheet(
                            'background-color: white; border: 1px solid black; border-radius: 10px; color: red;')
                        self.error_count += 1
                        self.erct.emit(self.error_count)
                        if self.error_count >= 3:
                            self.game_ended.emit()
                    self.current_text_color = self.selected_button.palette().text().color()
                    self.generated_grid[row][col] = int(digit)
                    if self.generated_grid == self.sudokulist:
                        self.game_ended.emit()

    def open_random_cell(self):
        empty_cells = [(i, j) for i in range(9) for j in range(9) if self.generated_grid[i][j] == 0]
        if empty_cells:
            i, j = random.choice(empty_cells)
            self.generated_grid[i][j] = self.sudokulist[i][j]
            button = self.buttons[i][j]
            button.setText(str(self.sudokulist[i][j]))
            button.setStyleSheet(
                f'background-color: white; border: 1px solid black; border-radius: 10px; color: #3474eb;')
            button.setEnabled(False)
            if self.generated_grid == self.sudokulist:
                self.game_ended.emit()


    def get_button_position(self, button):
        for i in range(9):
            for j in range(9):
                if self.buttons[i][j] == button:
                    return i, j
        return -1, -1

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
